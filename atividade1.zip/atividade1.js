function main(numero) {
    if (numero > 0) {
        return 'positivo';
    } else if (numero < 0) {
        return 'negativo';
    } else {
        return 'zero';
    }
}

console.log(main(2));
console.log(main(-2));
console.log(main(0));
function main(numero) {
  if (numero <= 1) {
    return false;
  }
  
  const valorMaximo = numero / 2;

  for (let i = 2; i <= valorMaximo; i++) {
    if (numero % i === 0) {
        return false;
    }
  }
  return true;
}

console.log(main(7));
console.log(main(6));
console.log(main(204));
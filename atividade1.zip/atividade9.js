function main(palavra1, palavra2) {
  const palavra1Organizada = palavra1
  .toLowerCase()
  .split(' ')
  .join('')
  .split('')
  .sort((a, b) => a - b)
  .join();
  const palavra2Organizada = palavra2
  .toLowerCase()
  .split(' ')
  .join('')
  .split('')
  .sort()
  .join();
  return palavra1Organizada === palavra2Organizada
}

console.log(main('dormitory', 'dirty rooa'));

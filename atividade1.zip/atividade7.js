function main(nota1, nota2, nota3) {
  const peso1 = 1;
  const peso2 = 2;
  const peso3 = 3;

  const somaPesos = peso1 + peso2 + peso3;
  const somaNotas = (peso1 * nota1) + (peso2 * nota2) + (peso3 * nota3);

  return somaNotas / somaPesos;
}

console.log(main(5, 5, 5));
console.log(main(10, 10, 10));
console.log(main(0, 0, 0));
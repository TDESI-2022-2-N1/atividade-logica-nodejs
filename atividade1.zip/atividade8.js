function main(texto) {
  texto = texto.toLowerCase();
  let texto2 = '';
  for (let index = texto.length - 1; index >= 0; index--) {
    const letra = texto[index];
    if (letra !== ' ') {
      texto2+=letra;
    }
  }
  return texto2===texto;
}

console.log(main(''));
console.log(main('hello'));
console.log(main('a man a plan a canal Panama'));
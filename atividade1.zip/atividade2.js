function main(numero) {
    return (numero**2) * Math.PI;
}

console.log(main(0));
console.log(main(1));
console.log(main(5));
function main(frase) {
    const vogais = 'aeiou';
    frase = frase.toLowerCase();
    let contador = 0;
    for (let index = 0; index < frase.length; index++) {
        const letra = frase[index];
        if (vogais.includes(letra)) {
            contador++;
        }
    }
    return contador;
}
console.log(main('HEllo World'));
console.log(main('banana'));
console.log(main(''));
function main(celsius) {
    return (celsius * 9/5) + 32;
}

console.log(main(0));
console.log(main(100));
console.log(main(-40));